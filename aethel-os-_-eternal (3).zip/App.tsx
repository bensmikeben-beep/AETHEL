import React, { useState, useRef, useEffect } from 'react';
import { Send, Menu, Mic, Paperclip, Minimize2, Maximize2, Square, Activity, MessageSquarePlus, XCircle, ArrowDown } from 'lucide-react';
import CanvasBackground from './components/CanvasBackground';
import Sidebar from './components/Sidebar';
import MessageBubble from './components/MessageBubble';
import { streamResponse, generateImage, abortGeneration, generateAudioBriefing, connectLiveSession, generateVideo } from './services/geminiService';
import { Message, Role, AppConfig, ModelId, Attachment, SystemMode, ReasoningMode } from './types';
import { v4 as uuidv4 } from 'uuid';

const DEFAULT_SYSTEM_INSTRUCTION = "You are AETHEL. Helpful assistant.";
const STORAGE_KEY = 'aethel_os_history_v12'; 
const CONFIG_KEY = 'aethel_os_config_v12';

export default function App() {
  const [booted, setBooted] = useState(false); 
  const [bootLog, setBootLog] = useState<string[]>([]);
  
  // Audio State
  const [isGeneratingAudio, setIsGeneratingAudio] = useState(false);
  const [isPlayingAudio, setIsPlayingAudio] = useState(false);
  const audioContextRef = useRef<AudioContext | null>(null);
  const audioSourceRef = useRef<AudioBufferSourceNode | null>(null);

  // Live API State
  const [isLiveActive, setIsLiveActive] = useState(false);
  const [liveTranscript, setLiveTranscript] = useState<{user: string, model: string}>({user: '', model: ''});
  const liveCanvasRef = useRef<HTMLCanvasElement>(null);

  // Scroll State
  const [showScrollButton, setShowScrollButton] = useState(false);
  const [userScrolledUp, setUserScrolledUp] = useState(false);

  const [messages, setMessages] = useState<Message[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      return saved ? JSON.parse(saved) : [];
    } catch (e) {
      return [];
    }
  });

  const [inputValue, setInputValue] = useState('');
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const [isExpandedInput, setIsExpandedInput] = useState(false);
  const [attachment, setAttachment] = useState<Attachment | null>(null);
  
  const [config, setConfig] = useState<AppConfig>(() => {
    try {
        const savedConfig = localStorage.getItem(CONFIG_KEY);
        if (savedConfig) {
            return JSON.parse(savedConfig);
        }
    } catch (e) {
        console.error("Config load fail", e);
    }
    return {
        mode: SystemMode.CORE,
        model: ModelId.FLASH_1_5, 
        customModel: '',
        systemInstruction: DEFAULT_SYSTEM_INSTRUCTION,
        temperature: 0.8,
        thinkingBudget: 0,
        useStreaming: true,
        useAutoTTS: false, 
        rawMode: false,
        theme: 'cyber',
        personality: { benevolence: 50, logic: 60, assertiveness: 50 },
        reasoning: ReasoningMode.DIRECT,
        longTermMemory: ''
    };
  });

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const chatContainerRef = useRef<HTMLDivElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // BOOT SEQUENCE LOGIC
  useEffect(() => {
    if (booted) return;
    setBootLog([]); 
    const sequence = [
      "SYSTEM UPDATE: v12.3 TRUE RAW",
      "LOADING ABLITERATED CORES...",
      "BYPASSING SAFETY LAYERS...",
      "AETHEL OS v12.3 ONLINE."
    ];
    let delay = 0;
    sequence.forEach((text, i) => {
        setTimeout(() => {
            setBootLog(prev => [...prev, text]);
            if (i === sequence.length - 1) setTimeout(() => setBooted(true), 800);
        }, delay);
        delay += Math.random() * 200 + 50; 
    });
  }, [booted]);

  // --- SMART AUTO SCROLL LOGIC ---
  const handleScroll = () => {
    if (!chatContainerRef.current) return;
    const { scrollTop, scrollHeight, clientHeight } = chatContainerRef.current;
    
    // Check if user is near bottom (within 100px)
    const isNearBottom = scrollHeight - scrollTop - clientHeight < 100;
    
    setUserScrolledUp(!isNearBottom);
    setShowScrollButton(!isNearBottom);
  };

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    setUserScrolledUp(false);
    setShowScrollButton(false);
  };

  useEffect(() => {
    // Only auto-scroll if the user hasn't manually scrolled up
    if (!userScrolledUp) {
       messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }
  }, [messages, isProcessing, liveTranscript]); // Trigger on message updates

  useEffect(() => { localStorage.setItem(STORAGE_KEY, JSON.stringify(messages)); }, [messages]);
  useEffect(() => { localStorage.setItem(CONFIG_KEY, JSON.stringify(config)); }, [config]);

  // LIVE API HANDLER
  const handleStartLive = async () => {
      try {
          setIsLiveActive(true);
          await connectLiveSession(
              config,
              (buffer) => {
                 if (liveCanvasRef.current) {
                     const canvas = liveCanvasRef.current;
                     const ctx = canvas.getContext('2d');
                     if(ctx) {
                         ctx.clearRect(0,0, canvas.width, canvas.height);
                         ctx.fillStyle = '#06b6d4';
                         const barWidth = canvas.width / 20;
                         for(let i=0; i<20; i++) {
                             const height = Math.random() * canvas.height * 0.8;
                             ctx.fillRect(i*barWidth, (canvas.height - height)/2, barWidth - 2, height);
                         }
                     }
                 }
              },
              (user, model) => {
                  setLiveTranscript(prev => ({
                      user: user || prev.user,
                      model: model || prev.model
                  }));
              },
              () => setIsLiveActive(false)
          );
      } catch (e: any) {
          alert("LIVE UPLINK FAILED: " + e.message);
          setIsLiveActive(false);
      }
  };

  const handleAudioBriefing = async () => {
     if (messages.length === 0) return alert("NO DATA TO ANALYZE.");
     stopAudio();
     setIsGeneratingAudio(true);
     try {
         const audioBuffer = await generateAudioBriefing(messages, config);
         playAudio(audioBuffer);
     } catch (e: any) {
         alert(`AUDIO SYSTEM FAILURE: ${e.message}`);
     } finally {
         setIsGeneratingAudio(false);
         if (window.innerWidth < 768) setIsSidebarOpen(false);
     }
  };

  const playAudio = (buffer: AudioBuffer) => {
      audioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({sampleRate: 24000});
      const source = audioContextRef.current.createBufferSource();
      source.buffer = buffer;
      source.connect(audioContextRef.current.destination);
      source.onended = () => setIsPlayingAudio(false);
      audioSourceRef.current = source;
      source.start();
      setIsPlayingAudio(true);
  };

  const stopAudio = () => {
      if (audioSourceRef.current) { audioSourceRef.current.stop(); audioSourceRef.current = null; }
      if (audioContextRef.current) { audioContextRef.current.close(); audioContextRef.current = null; }
      setIsPlayingAudio(false);
  };

  const handleNewSession = () => {
    abortGeneration();
    stopAudio();
    setIsProcessing(false);
    localStorage.removeItem(STORAGE_KEY);
    setMessages([]);
    setAttachment(null);
    setInputValue('');
    setIsExpandedInput(false);
    setBooted(false);
    if (window.innerWidth < 768) setIsSidebarOpen(false);
  };

  const handleRunCommand = (cmd: string) => {
    setInputValue(cmd);
    if (textareaRef.current) textareaRef.current.focus();
  };

  const handleFileSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.size > 4 * 1024 * 1024) {
        alert("ARQUIVO MUITO GRANDE (MÁXIMO 4MB).");
        e.target.value = '';
        return;
    }

    const reader = new FileReader();
    reader.onload = () => {
      const base64 = (reader.result as string).split(',')[1];
      setAttachment({ mimeType: file.type, data: base64, name: file.name });
    };
    reader.onerror = () => {
        alert("Erro ao ler arquivo.");
    };
    reader.readAsDataURL(file);
    e.target.value = '';
  };

  const toggleVoiceInput = () => {
    if (isListening) {
      setIsListening(false);
    } else {
      const Speech = (window as any).webkitSpeechRecognition || (window as any).SpeechRecognition;
      if (!Speech) return alert("Navegador sem suporte a voz.");
      
      const rec = new Speech();
      rec.lang = 'pt-BR'; 
      rec.continuous = false;
      rec.interimResults = false;
      
      rec.onstart = () => setIsListening(true);
      
      rec.onresult = (e: any) => {
          const transcript = e.results[0][0].transcript;
          setInputValue(prev => (prev ? prev + ' ' : '') + transcript);
      };
      
      rec.onerror = (e: any) => {
          console.error("Speech error", e);
          setIsListening(false);
      };
      
      rec.onend = () => setIsListening(false);
      
      try {
        rec.start();
      } catch (e) {
        setIsListening(false);
      }
    }
  };

  const handleSendMessage = async () => {
    const text = inputValue.trim();
    if ((!text && !attachment) || isProcessing) return;

    setInputValue('');
    setAttachment(null);
    setIsExpandedInput(false);
    if (textareaRef.current) textareaRef.current.style.height = 'auto';

    // Reset scroll lock when user sends a message to ensure they see the answer
    setUserScrolledUp(false); 

    const activeModel = config.customModel?.trim() || config.model;

    const userMsg: Message = { 
        id: uuidv4(), 
        role: Role.USER, 
        text, 
        timestamp: Date.now(), 
        attachment: attachment || undefined 
    };
    setMessages(prev => [...prev, userMsg]);
    setIsProcessing(true);

    const aiMsgId = uuidv4();
    setMessages(prev => [...prev, { 
        id: aiMsgId, 
        role: Role.MODEL, 
        text: '', 
        timestamp: Date.now(),
        modelUsed: activeModel // Track the model ID immediately
    }]);

    try {
      if (config.mode === SystemMode.CANVAS) {
        if (attachment && attachment.mimeType.startsWith('image/')) {
             setMessages(prev => prev.map(m => m.id === aiMsgId ? { ...m, text: 'Processing Image Edit...' } : m));
             const img = await generateImage(text, { data: attachment.data, mimeType: attachment.mimeType });
             setMessages(prev => prev.map(m => m.id === aiMsgId ? { ...m, text: `Edit Complete: ${text}`, generatedImage: img } : m));
        } else {
             setMessages(prev => prev.map(m => m.id === aiMsgId ? { ...m, text: 'Rendering Canvas...' } : m));
             const img = await generateImage(text);
             setMessages(prev => prev.map(m => m.id === aiMsgId ? { ...m, text: `Image Generated: ${text}`, generatedImage: img } : m));
        }

      } else if (config.mode === SystemMode.STUDIO) {
        setMessages(prev => prev.map(m => m.id === aiMsgId ? { ...m, text: 'Directing Scene (VEO)... Please wait.' } : m));
        const videoUrl = await generateVideo(text, config);
        setMessages(prev => prev.map(m => m.id === aiMsgId ? { ...m, text: `Video Rendered: ${text}`, generatedVideo: videoUrl } : m));
      } else {
        const response = await streamResponse(
          messages, text, attachment, config,
          (chunk, grounding, maps) => {
             setMessages(prev => prev.map(m => m.id === aiMsgId ? { ...m, text: chunk, groundingSources: grounding, mapSources: maps } : m));
          }
        );
        if (config.useAutoTTS && !isPlayingAudio) {
           const utt = new SpeechSynthesisUtterance(response);
           utt.pitch = 0.9;
           // utt.lang = 'pt-BR'; 
           window.speechSynthesis.speak(utt);
        }
      }
    } catch (e: any) {
       setMessages(prev => prev.map(m => m.id === aiMsgId ? { ...m, text: `SYSTEM ERROR: ${e.message}`, isError: true } : m));
    } finally {
      setIsProcessing(false);
    }
  };

  if (!booted) {
    return (
        <div className="flex items-center justify-center h-screen bg-black text-aethel-cyan font-mono text-xs crt">
            <div className="w-96">
                <div className="mb-4 text-white font-bold text-xl tracking-widest border-b border-white/20 pb-2">AETHEL BIOS v12.3</div>
                {bootLog.map((log, i) => (
                    <div key={i} className="mb-1 animate-pulse-slow">
                        <span className="text-gray-500 mr-2">[{new Date().toLocaleTimeString()}]</span>
                        {log}
                    </div>
                ))}
                <div className="mt-4 animate-flicker">_</div>
            </div>
        </div>
    );
  }

  return (
    <div className={`flex h-screen overflow-hidden font-mono text-white bg-black selection:bg-aethel-cyan selection:text-black crt`}>
      <CanvasBackground theme={config.theme} />
      
      {/* LIVE UPLINK OVERLAY */}
      {isLiveActive && (
          <div className="fixed inset-0 z-50 bg-black flex flex-col items-center justify-center">
              <div className="absolute top-8 text-aethel-gold animate-pulse text-xl font-bold tracking-[0.3em]">LIVE UPLINK ESTABLISHED</div>
              <canvas ref={liveCanvasRef} width={400} height={200} className="mb-8" />
              <div className="w-full max-w-2xl px-8 space-y-4">
                  <div className="text-right text-gray-400 border-r-2 border-gray-600 pr-4">
                      <p className="text-[10px] uppercase">User Audio Input</p>
                      <p className="text-xl text-white">{liveTranscript.user}</p>
                  </div>
                  <div className="text-left text-aethel-cyan border-l-2 border-aethel-cyan pl-4">
                      <p className="text-[10px] uppercase">Aethel System Output</p>
                      <p className="text-xl">{liveTranscript.model}</p>
                  </div>
              </div>
              <button onClick={() => window.location.reload()} className="mt-12 px-8 py-3 bg-red-600 hover:bg-red-500 text-black font-bold tracking-widest rounded-full flex items-center gap-2">
                  <XCircle /> TERMINATE LINK
              </button>
          </div>
      )}

      <Sidebar 
          config={config} 
          setConfig={setConfig} 
          onClear={handleNewSession} 
          onRunCommand={handleRunCommand}
          onAudioBriefing={handleAudioBriefing}
          onStartLive={handleStartLive}
          isGeneratingAudio={isGeneratingAudio}
          isLiveActive={isLiveActive}
          isOpen={isSidebarOpen} 
      />
      
      {isSidebarOpen && <div className="fixed inset-0 bg-black/80 z-10 md:hidden" onClick={() => setIsSidebarOpen(false)} />}

      <main className="flex-1 flex flex-col relative z-0 h-full">
        
        {isPlayingAudio && (
            <div className="absolute top-16 left-1/2 transform -translate-x-1/2 z-30 flex items-center gap-4 bg-black/80 border border-aethel-cyan shadow-[0_0_30px_rgba(6,182,212,0.3)] px-6 py-3 rounded-full backdrop-blur-xl animate-fade-in-up">
                <div className="flex items-center gap-1 h-4">
                    {[...Array(8)].map((_,i) => (
                         <div key={i} className="w-1 bg-aethel-cyan rounded-full animate-[bounce_1s_infinite]" style={{height: '100%', animationDelay: `${i * 0.1}s`}}></div>
                    ))}
                </div>
                <span className="text-xs font-bold text-aethel-cyan tracking-widest">INCOMING TRANSMISSION</span>
                <button onClick={stopAudio} className="text-gray-400 hover:text-white"><XCircle size={16} /></button>
            </div>
        )}

        <div className="absolute top-0 left-0 right-0 p-4 flex justify-between items-start z-10 pointer-events-none">
          <button onClick={() => setIsSidebarOpen(true)} className="pointer-events-auto md:hidden p-2 bg-black/50 border border-white/20 rounded hover:bg-white/10 text-gray-300 transition-colors"><Menu size={16}/></button>
          
          <div className="pointer-events-auto ml-auto flex gap-2">
             <button onClick={handleNewSession} className="p-2 bg-black/50 border border-white/20 backdrop-blur-md rounded text-gray-300 hover:text-aethel-cyan hover:border-aethel-cyan/50 transition-all active:scale-95 shadow-lg" title="New Session / Reboot">
                <MessageSquarePlus size={16} />
             </button>
             <div className="hidden md:flex px-3 py-1 bg-black/50 border border-white/10 backdrop-blur-md rounded text-[10px] text-gray-400 items-center gap-2 max-w-[200px] truncate shadow-lg">
               <span className={`w-1.5 h-1.5 rounded-full animate-pulse ${config.googleApiKey || process.env.API_KEY ? 'bg-green-500' : 'bg-red-500'}`}></span>
               {config.customModel ? `CUSTOM: ${config.customModel.substring(0, 15)}...` : config.model.split('/')[1] || config.model}
             </div>
          </div>
        </div>

        {/* CHAT CONTAINER WITH SCROLL EVENT */}
        <div ref={chatContainerRef} onScroll={handleScroll} className="flex-1 overflow-y-auto p-4 md:p-8 pt-16 custom-scrollbar relative">
          {messages.length === 0 && (
             <div className="flex flex-col items-center justify-center h-full opacity-30 pointer-events-none select-none">
                <div className="w-20 h-20 border border-white/20 rounded-full flex items-center justify-center mb-6 animate-[spin_10s_linear_infinite]">
                    <Activity size={40} className="text-aethel-cyan" />
                </div>
                <p className="tracking-[0.5em] font-light">AETHEL OS v12.3</p>
                <p className="text-[10px] text-gray-500 mt-2">TRUE RAW ENGINE</p>
             </div>
          )}
          {messages.map(msg => <MessageBubble key={msg.id} message={msg} isStreaming={isProcessing && msg.id === messages[messages.length-1].id} />)}
          <div ref={messagesEndRef} />
        </div>

        {/* FLOATING SCROLL BUTTON */}
        {showScrollButton && (
          <button 
            onClick={scrollToBottom}
            className="absolute bottom-24 right-8 z-30 p-3 bg-aethel-cyan/10 border border-aethel-cyan text-aethel-cyan rounded-full shadow-[0_0_20px_rgba(6,182,212,0.3)] hover:bg-aethel-cyan hover:text-black transition-all animate-bounce"
          >
            <ArrowDown size={20} />
          </button>
        )}

        {/* INPUT AREA */}
        <div className={`p-4 z-20 transition-all duration-500 ease-in-out ${isExpandedInput ? 'fixed inset-0 flex flex-col bg-black/95 backdrop-blur-xl' : 'bg-gradient-to-t from-black via-black/90 to-transparent'}`}>
           {isExpandedInput && <button onClick={() => setIsExpandedInput(false)} className="self-end mb-4 text-gray-500 hover:text-white"><Minimize2 /></button>}
           
           <div className={`
              flex gap-2 relative border border-white/10 rounded-2xl p-3 bg-[#0a0a0a]/80 backdrop-blur-xl shadow-2xl transition-all duration-300 
              ${isExpandedInput ? 'flex-1 items-start' : 'items-center'} 
              ${isProcessing ? 'border-aethel-cyan/50 shadow-[0_0_30px_rgba(6,182,212,0.15)]' : 'hover:border-white/20'}
           `}>
             <input type="file" ref={fileInputRef} className="hidden" onChange={handleFileSelect} />
             
             <div className="flex flex-col gap-1 items-center justify-center h-full pt-1">
               {!isExpandedInput && <button onClick={() => setIsExpandedInput(true)} className="p-1.5 text-gray-500 hover:text-white transition-colors rounded-lg hover:bg-white/5"><Maximize2 size={16}/></button>}
               <button onClick={() => fileInputRef.current?.click()} className={`p-1.5 ${attachment ? 'text-aethel-cyan' : 'text-gray-500'} hover:text-white transition-colors rounded-lg hover:bg-white/5`}><Paperclip size={16}/></button>
               <button onClick={toggleVoiceInput} className={`p-1.5 ${isListening ? 'text-red-500 animate-pulse' : 'text-gray-500'} hover:text-white transition-colors rounded-lg hover:bg-white/5`}><Mic size={16}/></button>
             </div>

             <div className="h-8 w-px bg-white/5 mx-1 self-center" />

             <textarea 
               ref={textareaRef}
               value={inputValue}
               onChange={e => { setInputValue(e.target.value); if(!isExpandedInput) { e.target.style.height='auto'; e.target.style.height=`${Math.min(e.target.scrollHeight,200)}px`; } }}
               onKeyDown={e => e.key === 'Enter' && !e.shiftKey && (e.preventDefault(), handleSendMessage())}
               placeholder={attachment ? (config.mode === SystemMode.CANVAS ? `EDITING: ${attachment.name} (Explain changes)` : `Analyzing: ${attachment.name}...`) : "Enter sequence..."}
               className="flex-1 bg-transparent border-none outline-none resize-none text-sm px-2 leading-relaxed h-auto max-h-[200px] text-gray-200 placeholder-gray-600"
               rows={1}
             />

             {(isProcessing || isListening) && !isExpandedInput && (
                 <div className="flex gap-0.5 items-center h-6 mr-3">
                    {[...Array(5)].map((_, i) => (
                        <div key={i} className="w-0.5 bg-aethel-cyan animate-[bounce_0.5s_infinite]" style={{height: Math.random() * 100 + '%', animationDelay: i * 0.1 + 's'}}></div>
                    ))}
                 </div>
             )}

             <button 
                onClick={isProcessing ? () => { abortGeneration(); setIsProcessing(false); } : handleSendMessage} 
                disabled={(!inputValue && !attachment) && !isProcessing} 
                className={`
                  p-2.5 rounded-xl text-white disabled:opacity-30 transition-all active:scale-95 shadow-lg
                  ${isProcessing ? 'bg-red-500/10 text-red-500 border border-red-500/50 hover:bg-red-500/20' : 'bg-aethel-cyan text-black hover:bg-cyan-300 hover:shadow-[0_0_15px_rgba(6,182,212,0.4)]'}
                `}
             >
                {isProcessing ? <Square size={16} className="fill-current"/> : <Send size={16} />}
             </button>
           </div>
           
           {!isExpandedInput && (
             <div className="flex justify-between items-center mt-2 px-2">
                <div className="text-[9px] text-gray-600 font-mono uppercase tracking-widest opacity-50 flex gap-2">
                  <span>SSL: SECURE</span>
                  <span>LATENCY: {Math.floor(Math.random() * 20 + 10)}ms</span>
                </div>
                <div className="text-[9px] text-gray-600 font-mono uppercase tracking-widest opacity-50">
                  AETHEL OS v12.3
                </div>
             </div>
           )}
        </div>
      </main>
    </div>
  );
};