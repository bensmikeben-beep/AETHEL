import React, { useEffect, useRef } from 'react';

interface CanvasBackgroundProps {
  theme: 'cyber' | 'matrix';
}

const CanvasBackground: React.FC<CanvasBackgroundProps> = ({ theme }) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let width = window.innerWidth;
    let height = window.innerHeight;
    canvas.width = width;
    canvas.height = height;

    let animationFrameId: number;
    let particles: any[] = [];
    let matrixColumns: number[] = [];
    
    // Matrix Config
    const fontSize = 14;
    
    const init = () => {
      width = window.innerWidth;
      height = window.innerHeight;
      canvas.width = width;
      canvas.height = height;

      if (theme === 'cyber') {
        particles = [];
        for (let i = 0; i < 70; i++) {
          particles.push({
            x: Math.random() * width,
            y: Math.random() * height,
            s: Math.random() * 2,
            v: Math.random() * 0.4 + 0.1
          });
        }
      } else if (theme === 'matrix') {
        const columns = Math.floor(width / fontSize);
        matrixColumns = Array(columns).fill(1);
      }
    };

    const animate = () => {
      if (theme === 'cyber') {
        ctx.clearRect(0, 0, width, height);
        ctx.fillStyle = 'rgba(255, 255, 255, 0.6)';
        particles.forEach(p => {
          p.y -= p.v;
          if (p.y < 0) {
            p.y = height;
            p.x = Math.random() * width;
          }
          ctx.beginPath();
          ctx.arc(p.x, p.y, p.s, 0, Math.PI * 2);
          ctx.fill();
        });
      } else if (theme === 'matrix') {
        ctx.fillStyle = 'rgba(0, 0, 0, 0.05)';
        ctx.fillRect(0, 0, width, height);
        
        ctx.fillStyle = '#0F0'; // Matrix Green
        ctx.font = `${fontSize}px monospace`;
        
        for (let i = 0; i < matrixColumns.length; i++) {
          const text = String.fromCharCode(0x30A0 + Math.random() * 96);
          ctx.fillText(text, i * fontSize, matrixColumns[i] * fontSize);
          
          if (matrixColumns[i] * fontSize > height && Math.random() > 0.975) {
            matrixColumns[i] = 0;
          }
          matrixColumns[i]++;
        }
      }
      animationFrameId = requestAnimationFrame(animate);
    };

    window.addEventListener('resize', init);
    init();
    animate();

    return () => {
      window.removeEventListener('resize', init);
      cancelAnimationFrame(animationFrameId);
    };
  }, [theme]);

  return (
    <canvas 
      ref={canvasRef} 
      className={`fixed top-0 left-0 w-full h-full -z-10 pointer-events-none transition-opacity duration-1000 ${theme === 'matrix' ? 'opacity-20' : 'opacity-30'}`}
    />
  );
};

export default CanvasBackground;