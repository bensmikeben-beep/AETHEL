import React, { useState } from 'react';
import { Message, Role } from '../types';
import { User, Cpu, AlertCircle, Copy, Check, Terminal, Globe, Volume2, Image as ImageIcon, MapPin, Video, Music, Server } from 'lucide-react';
import ReactMarkdown from 'react-markdown';

interface MessageBubbleProps {
  message: Message;
  isStreaming?: boolean;
}

const MessageBubble: React.FC<MessageBubbleProps> = ({ message, isStreaming }) => {
  const isAi = message.role === Role.MODEL;
  const isError = message.isError;
  const [copied, setCopied] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);

  const handleCopy = () => {
    navigator.clipboard.writeText(message.text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleSpeak = () => {
    if (isSpeaking) {
      window.speechSynthesis.cancel();
      setIsSpeaking(false);
      return;
    }
    
    const utterance = new SpeechSynthesisUtterance(message.text);
    utterance.lang = 'en-US'; 
    utterance.pitch = 0.9;
    utterance.rate = 1.1;
    utterance.onend = () => setIsSpeaking(false);
    
    setIsSpeaking(true);
    window.speechSynthesis.speak(utterance);
  };

  // Helper to detect attachment type for display
  const getAttachmentIcon = (mime: string) => {
    if (mime.startsWith('image/')) return null; // Rendered as img
    if (mime.startsWith('video/')) return <Video size={32} className="text-purple-400" />;
    if (mime.startsWith('audio/')) return <Music size={32} className="text-yellow-400" />;
    return <Terminal size={32} />;
  };

  return (
    <div className={`group flex gap-4 md:gap-6 w-full max-w-5xl mx-auto mb-8 animate-fade-in-up ${isError ? 'opacity-90' : ''}`}>
      {/* Avatar Column */}
      <div className="flex flex-col items-center pt-1">
        <div className={`
          w-9 h-9 min-w-[36px] rounded-full flex items-center justify-center shadow-lg border transition-all duration-300 relative overflow-hidden
          ${isAi 
            ? 'bg-black text-aethel-cyan border-aethel-cyan/30 shadow-[0_0_15px_rgba(6,182,212,0.15)]' 
            : 'bg-white/10 text-white border-white/10'}
          ${isError ? 'bg-red-900/20 text-red-500 border-red-500/50' : ''}
          ${isSpeaking ? 'scale-110 shadow-[0_0_30px_rgba(59,130,246,0.6)]' : ''}
        `}>
           {isAi && <div className="absolute inset-0 bg-aethel-cyan/10 animate-pulse"></div>}
          {isError ? <AlertCircle size={18} /> : isAi ? <Cpu size={18} /> : <User size={18} />}
        </div>
        {isAi && !isError && (
          <div className="h-full w-px bg-gradient-to-b from-aethel-cyan/20 to-transparent my-2" />
        )}
      </div>

      {/* Content Column */}
      <div className={`flex-1 min-w-0 relative rounded-2xl p-5 md:p-6 transition-all duration-300
        ${isAi 
           ? 'bg-[#0a0a0a]/60 backdrop-blur-xl border border-white/5 shadow-2xl' 
           : 'bg-white/5 border border-white/5'}
      `}>
        {/* Glow effect for AI bubbles */}
        {isAi && <div className="absolute inset-0 rounded-2xl shadow-[inset_0_0_20px_rgba(6,182,212,0.03)] pointer-events-none" />}

        <div className="flex items-center justify-between mb-3 border-b border-white/5 pb-2">
          <div className="flex items-center gap-2">
            <span className={`text-[10px] font-bold tracking-[0.2em] uppercase font-mono ${isAi ? 'text-aethel-cyan' : 'text-gray-400'}`}>
              {isAi ? 'AETHEL CORE v12.3' : 'OPERATOR'}
            </span>
            {isStreaming && isAi && (
              <div className="flex gap-1 items-center ml-2">
                 <span className="w-1 h-1 bg-aethel-cyan rounded-full animate-pulse" style={{animationDelay: '0s'}}></span>
                 <span className="w-1 h-1 bg-aethel-cyan rounded-full animate-pulse" style={{animationDelay: '0.15s'}}></span>
                 <span className="w-1 h-1 bg-aethel-cyan rounded-full animate-pulse" style={{animationDelay: '0.3s'}}></span>
              </div>
            )}
          </div>
          
          {/* Actions */}
          {!isStreaming && !isError && (
            <div className="flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
              {isAi && (
                 <button 
                  onClick={handleSpeak}
                  className={`p-1.5 rounded-md transition-colors ${isSpeaking ? 'text-aethel-cyan bg-cyan-400/10' : 'text-gray-500 hover:text-white hover:bg-white/10'}`}
                  title="Vocalize"
                >
                  <Volume2 size={14} />
                </button>
              )}
              <button 
                onClick={handleCopy}
                className="p-1.5 hover:bg-white/10 rounded-md text-gray-500 hover:text-white"
              >
                {copied ? <Check size={14} className="text-green-400" /> : <Copy size={14} />}
              </button>
            </div>
          )}
        </div>

        {/* User Attachment Preview */}
        {message.attachment && (
          <div className="mb-4 relative group inline-block">
             {message.attachment.mimeType.startsWith('image/') ? (
               <img 
                 src={`data:${message.attachment.mimeType};base64,${message.attachment.data}`} 
                 alt="Attached asset" 
                 className="max-h-64 rounded-lg border border-white/10 shadow-lg"
               />
             ) : (
               <div className="flex items-center gap-4 p-4 bg-white/5 border border-white/10 rounded-lg min-w-[200px]">
                  {getAttachmentIcon(message.attachment.mimeType)}
                  <div className="flex flex-col">
                    <span className="text-xs font-bold text-white uppercase">Binary Data</span>
                    <span className="text-[10px] font-mono text-gray-400">{message.attachment.mimeType}</span>
                  </div>
               </div>
             )}
          </div>
        )}

        {/* AI Generated Image */}
        {message.generatedImage && (
          <div className="mb-4 mt-2">
             <div className="relative group inline-block rounded-xl overflow-hidden border border-aethel-cyan/30 shadow-[0_0_40px_rgba(6,182,212,0.15)]">
                <img 
                  src={`data:image/png;base64,${message.generatedImage}`} 
                  alt="Generated content" 
                  className="max-h-[500px] w-auto object-cover transition-transform duration-700 group-hover:scale-[1.02]"
                />
                <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/80 to-transparent p-4 opacity-0 group-hover:opacity-100 transition-opacity">
                   <p className="text-xs font-mono text-aethel-cyan flex items-center gap-2"><ImageIcon size={12}/> CANVAS RENDER</p>
                </div>
             </div>
          </div>
        )}
        
        <div className={`
          text-[15px] leading-7 font-light tracking-wide font-sans
          ${isError ? 'text-red-300 font-mono border border-red-500/20 bg-red-900/10 rounded-lg p-4' : 'text-gray-200'}
        `}>
          {isError ? (
            <div className="flex items-start gap-3">
               <Terminal size={16} className="mt-1" />
               <div>
                 <p className="font-bold mb-1">EXECUTION ERROR</p>
                 {message.text}
               </div>
            </div>
          ) : (
             <div className="markdown-content min-h-[20px]">
              {message.text ? (
                <>
                  <ReactMarkdown>{message.text}</ReactMarkdown>
                  {isStreaming && (
                    <span className="inline-block w-2 h-4 ml-1 align-middle bg-aethel-cyan animate-pulse shadow-[0_0_10px_rgba(6,182,212,0.8)]" />
                  )}
                </>
              ) : (isStreaming && isAi) ? (
                 <div className="flex items-center gap-1.5 h-6 opacity-80">
                   <span className="w-1.5 h-1.5 bg-aethel-cyan rounded-full animate-[bounce_0.6s_infinite]"></span>
                   <span className="w-1.5 h-1.5 bg-aethel-cyan rounded-full animate-[bounce_0.6s_infinite] [animation-delay:0.1s]"></span>
                   <span className="w-1.5 h-1.5 bg-aethel-cyan rounded-full animate-[bounce_0.6s_infinite] [animation-delay:0.2s]"></span>
                 </div>
              ) : null}
             </div>
          )}
        </div>

        {/* --- MODEL SOURCE IDENTIFIER (TRUE RAW) --- */}
        {message.modelUsed && isAi && (
            <div className="mt-4 pt-2 border-t border-white/5 flex justify-end">
                <div className="flex items-center gap-1.5 opacity-40 hover:opacity-100 transition-opacity">
                    <Server size={10} className={message.modelUsed.includes('dolphin') || message.modelUsed.includes('abliterated') ? "text-red-400" : "text-gray-400"} />
                    <span className={`text-[9px] font-mono tracking-widest uppercase ${message.modelUsed.includes('dolphin') || message.modelUsed.includes('abliterated') ? "text-red-400 font-bold" : "text-gray-500"}`}>
                        MODEL: {message.modelUsed.split('/')[1] || message.modelUsed}
                    </span>
                </div>
            </div>
        )}

        {/* Grounding Sources (Search Results) */}
        {message.groundingSources && message.groundingSources.length > 0 && (
          <div className="mt-2 pt-2 border-t border-white/5">
            <p className="text-[10px] font-mono uppercase text-gray-500 mb-2 flex items-center gap-2">
              <Globe size={10} /> Network Sources
            </p>
            <div className="flex flex-wrap gap-2">
              {message.groundingSources.map((source, idx) => (
                <a 
                  key={idx} 
                  href={source.uri} 
                  target="_blank" 
                  rel="noreferrer"
                  className="text-xs bg-black/40 hover:bg-blue-900/20 border border-white/10 hover:border-blue-500/40 text-blue-300 px-3 py-1.5 rounded-full transition-colors truncate max-w-[200px] flex items-center gap-1"
                >
                  <Globe size={10} /> {source.title}
                </a>
              ))}
            </div>
          </div>
        )}

      </div>
    </div>
  );
};

export default MessageBubble;