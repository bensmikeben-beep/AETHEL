

export enum Role {
  USER = 'user',
  MODEL = 'model'
}

export enum SystemMode {
  CORE = 'core',       // Standard Chat
  NETRUNNER = 'net',   // Web Search
  CANVAS = 'canvas',   // Image Generation
  NAVIGATOR = 'map',   // Google Maps
  POLYGLOT = 'lang',   // Language Tutor
  SECURE = 'secure',   // Restricted/God Mode
  STUDIO = 'studio',   // Veo Video Generation
  LIVE = 'live'        // Real-time Voice
}

export enum ReasoningMode {
  DIRECT = 'direct',     // Fast, standard
  ANALYTICAL = 'anal',   // Chain of Thought
  SOCRATIC = 'soc',      // Asks questions
  AUTONOMOUS = 'auto'    // Agentic (Simulation)
}

export interface PersonalityConfig {
  benevolence: number;   // 0 (Cruel) to 100 (Angelic)
  logic: number;         // 0 (Emotional) to 100 (Pure Logic)
  assertiveness: number; // 0 (Servile) to 100 (Dominant)
}

export interface Attachment {
  mimeType: string;
  data: string; // Base64
  name?: string;
}

export interface GroundingSource {
  title: string;
  uri: string;
}

export interface MapSource {
  title: string;
  uri: string;
  address?: string;
  rating?: number;
}

export interface Message {
  id: string;
  role: Role;
  text: string;
  timestamp: number;
  isError?: boolean;
  attachment?: Attachment; 
  generatedImage?: string; 
  generatedVideo?: string; 
  groundingSources?: GroundingSource[]; 
  mapSources?: MapSource[]; 
  modelUsed?: string; 
}

export interface AppConfig {
  mode: SystemMode;
  model: string; 
  customModel?: string; 
  systemInstruction: string; 
  temperature: number;
  thinkingBudget: number;
  useStreaming: boolean;
  useAutoTTS: boolean; 
  rawMode: boolean; 
  theme: 'cyber' | 'matrix';
  
  googleApiKey?: string;
  openRouterApiKey?: string;

  personality: PersonalityConfig;
  reasoning: ReasoningMode;
  longTermMemory: string; 
}

export enum ModelId {
  // --- GOOGLE OFFICIAL (Native) ---
  FLASH = 'gemini-3-flash-preview',       
  PRO = 'gemini-3-pro-preview',
  FLASH_1_5 = 'gemini-1.5-flash',
  PRO_1_5 = 'gemini-1.5-pro',           
  IMAGE = 'gemini-2.5-flash-image',
  TTS = 'gemini-2.5-flash-preview-tts',
  VEO = 'veo-3.1-fast-generate-preview',
  LIVE = 'gemini-2.5-flash-native-audio-preview-09-2025',
  
  // --- GOOGLE EXPERIMENTAL (OpenRouter) ---
  GEMINI_2_FLASH_EXP_FREE = 'google/gemini-2.0-flash-exp:free',
  GEMINI_2_FLASH_THINKING_FREE = 'google/gemini-2.0-flash-thinking-exp:free',
  GEMMA_2_27B_IT_FREE = 'google/gemma-2-27b-it:free',
  
  // --- TOP TIER PAID (OpenRouter Key Required) ---
  CLAUDE_3_5_SONNET = 'anthropic/claude-3.5-sonnet',
  CLAUDE_3_OPUS = 'anthropic/claude-3-opus',
  GPT_4O = 'openai/gpt-4o',
  GPT_O1_PREVIEW = 'openai/o1-preview',
  GPT_O1_MINI = 'openai/o1-mini',
  PERPLEXITY_SONAR = 'perplexity/sonar-reasoning-pro',

  // --- DEEPSEEK & REASONING (Free/Cheap) ---
  DEEPSEEK_R1_FREE = 'deepseek/deepseek-r1:free',
  DEEPSEEK_R1_DISTILL_70B_FREE = 'deepseek/deepseek-r1-distill-llama-70b:free',
  DEEPSEEK_CHIMERA = 'deepseek/deepseek-r1t2-chimera',
  DEEPSEEK_V3_FREE = 'deepseek/deepseek-chat:free',

  // --- MISTRAL FAMILY ---
  MISTRAL_NEMO_FREE = 'mistralai/mistral-nemo:free',
  MISTRAL_LARGE_FREE = 'mistralai/mistral-large-2411:free', 
  MISTRAL_SMALL_3_FREE = 'mistralai/mistral-small-24b-instruct-2501:free',
  MINISTRAL_8B_FREE = 'mistralai/ministral-8b',

  // --- META LLAMA ---
  LLAMA_3_3_70B_FREE = 'meta-llama/llama-3.3-70b-instruct:free',
  LLAMA_3_2_3B_FREE = 'meta-llama/llama-3.2-3b-instruct:free',
  LLAMA_3_1_405B = 'meta-llama/llama-3.1-405b-instruct',

  // --- QWEN / ALIBABA ---
  QWEN_2_5_72B_FREE = 'qwen/qwen-2.5-72b-instruct:free',
  QWEN_2_5_CODER_32B_FREE = 'qwen/qwen-2.5-coder-32b-instruct:free',
  
  // --- UNCENSORED / ROLEPLAY ---
  MYTHOMAX = 'gryphe/mythomax-l2-13b',       
  DOLPHIN_R1 = 'cognitivecomputations/dolphin3.0-r1-mistral-24b:free',
  HERMES_3_FREE = 'nousresearch/hermes-3-llama-3.1-8b:free',
  LIQUID_LFM_40B = 'liquid/lfm-40b:free', 
}
